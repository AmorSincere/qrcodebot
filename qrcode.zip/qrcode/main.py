import os
import time

from PIL import Image
from pyzbar.pyzbar import decode
import qrcode
from os.path import join as join_path
from pathlib import Path

import requests
from aiogram import Bot, Dispatcher, executor, types

BASE_URL = Path(__file__).parent
TOKEN = "5931353270:AAGkXSU-5WWtsr3D1LQeCKs7TnCs70avO0E"
bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

from uuid import uuid4


def gen_name():
    kode = str(uuid4()) + '.png'
    return kode


def gen_code(filename):
    filename = filename.split('.')[-1]
    kode = str(uuid4())
    kode = kode.replace('-', '')
    kode = kode + '.' + filename
    return kode


def decoder(folder):
    try:
        img = Image.open(folder)
        decoded = decode(img)
        return decoded[0].data.decode("utf-8")
    except Exception as error:
        return f"can't decode. error:{error}"


def qrcodefuntion(text: str):
    try:
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(text)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")
        photo_name = gen_name()
        img.save(join_path(BASE_URL, 'db', photo_name))
        return ['done', photo_name]
    except Exception as err:
        return err


async def message_is_text(message: types.Message):
    is_done = qrcodefuntion(message.text)
    if is_done[0] == 'done':
        try:
            with open(join_path(BASE_URL, 'db', is_done[1]), mode='rb') as file:
                await message.bot.send_photo(photo=file, chat_id=message.chat.id)
            time.sleep(2)
            os.remove(join_path(BASE_URL, 'db', is_done[1]))
        except Exception as error:
            await message.reply(f"Error occcured: {error}")
    else:
        await message.answer(is_done.__str__())


async def message_is_document(message: types.Message):
    try:
        kode = gen_code(message.document.file_name)
        folder = join_path(BASE_URL, 'db')
        file_id = message.document.file_id
        file_info = await bot.get_file(file_id)
        file_path = file_info['file_path']
        file_url = f'https://api.telegram.org/file/bot{TOKEN}/{file_path}'
        r = requests.get(file_url, stream=True)
        with open(join_path(folder, kode), "wb") as Pypdf:
            for chunk in r.iter_content(chunk_size=1024):
                if chunk:
                    Pypdf.write(chunk)
        decoded_text = decoder(join_path(folder, kode))
        await message.answer(decoded_text)
        with open(join_path(folder, kode), "rb") as Pypdf:
            await message.bot.send_document(document=Pypdf, chat_id=message.chat.id)
        time.sleep(2)
        os.remove(join_path(folder, kode))
    except Exception as error:
        await message.answer(error.__str__())
    finally:
        await message.answer("have a good time!")


async def message_is_photo(message: types.Message):
    try:
        file_id = message.photo[-1].file_id
        file_info = await bot.get_file(file_id)
        file_path = file_info['file_path']
        kode = gen_code(file_path)
        folder = join_path(BASE_URL, 'db', kode)
        file_url = f'https://api.telegram.org/file/bot{TOKEN}/{file_path}'
        r = requests.get(file_url, stream=True)
        with open(folder, "wb") as Pypdf:
            for chunk in r.iter_content(chunk_size=1024):
                if chunk:
                    Pypdf.write(chunk)
        decoded_text = decoder(folder)
        await message.answer(decoded_text)
        time.sleep(2)
        os.remove(folder)
    except Exception as error:
        await message.answer(error.__str__())
    finally:
        await message.answer("have a nice time!")


@dp.message_handler(commands=['start'])
async def start_handler(message: types.Message):
    await message.answer("Assalomu alaykum")


@dp.message_handler(content_types=[types.ContentType.PHOTO, types.ContentType.DOCUMENT, 'text'])
async def echo(message: types.Message):
    if message.document:
        await message_is_document(message)

    elif message.photo:
        await message_is_photo(message)
    else:
        await message_is_text(message)


if __name__ == '__main__':
    executor.start_polling(dp)
